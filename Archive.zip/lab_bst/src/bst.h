/**
 * @file BST.h
 * Declaraction of the BST class. You will probably need to modify this
 * file to add helper functions.
 */

#pragma once

#include <iostream>
#include <vector>
#include <sstream>
#include <string>
#include "utils.h"

/**
 * The BST class represents a linked-memory BST Tree.
 * @tparam K the type of key stored in the tree
 * @tparam V the type of value stored in the tree
 */
template <class K, class V>
class BST
{
  private:
    /**
     * Node represents a tree node; that is, an element in a BST.
     * It stores a key, value, and pointers to its left and right children.
     */
    struct Node {
        K key;
        V value;
        Node* left;
        Node* right;

        /**
         * Node constructor; sets children to point to `NULL`.
         * @param newKey The object to use as a key
         * @param newValue The templated data element that the constructed
         *  node will hold.
         */
        Node(const K& newKey, const V& newValue)
            : key(newKey), value(newValue), left(NULL), right(NULL)
        {
        }
    };

  public:
    /**
     * Constructor to create an empty tree.
     */
    BST();

    /**
     * Copy constructor.
     * @param other The tree to copy
     */
    BST(const BST& other);

    /**
     * Destructor; frees all nodes associated with this tree.
     */
    ~BST();

    /**
     * Assignment operator.
     * @param rhs The tree to copy
     * @return A reference to the current tree
     */
    const BST& operator=(const BST& rhs);

    /**
     * Frees all nodes associated with this tree and sets it to be empty.
     */
    void clear();

    /**
    * @return The height of the binary tree. Recall that the height of a binary
    *  tree is just the length of the longest path from the root to a leaf, and
    *  that the height of an empty tree is -1.
    */
    int height() const;

    /**
     * Inserts a key and value into the BST.
     * @param key The key to insert
     * @param value The value associated with the key
     */
    void insert(const K& key, const V& value);

    /**
     * Removes a key from the BST. The key is assumed to exist in the tree.
     * @param key The key to remove
     */
    void remove(const K& key);

    /**
     * Finds an element in the BST tree.
     * @param key The element to search for
     * @return The value stored for that key
     */
    V find(const K& key);

    /**
     * Prints the function calls to a stream.
     * @param out The stream to print to (default is stdout)
     */
    void printFunctionOrder(std::ostream& out = std::cout) const;

    /**
     * Prints the BST to a stream.
     * @param out The stream to print to (default is stdout)
     */
    void print(std::ostream& out = std::cout, bool order = true) const;

    /**
     * This function is used for grading.
     * @param newOut The stream to print to
     */
    void setOutput(std::ostream& newOut);

    /**
     * Gets the in-order traversal of an BST tree's keys.
     */
    std::vector<K> getInorderTraversal() const;

    /**
     * Gets the pre-order traversal of an BST tree's keys.
     */
    std::vector<K> getPreorderTraversal() const;

    /*
    * Gets vector of function calls.
    */
    std::vector<std::string> getFunctionOrder() const;

  private:
    /**
     * The root of the tree.
     */
    Node* root;

    /**
     * Private helper function for the public #insert function.
     * @param node The current node in the recursion
     * @param key The key to insert
     * @param value The value associated with the key
     */
    void insert(Node*& node, const K& key, const V& value);

    /**
     * Private helper function for the public #remove function.
     * @param node The current node in the recursion
     * @param key The key to remove
     */
    void remove(Node*& node, const K& key);

    /**
     * Finds a value (by key) in the BST tree.
     * @param node The node to search from (current subroot)
     * @param key The key to search for
     * @return A BST<K, V>::Node* & object pointing to the matching node
     */
    struct BST<K, V>::Node* &  find(Node*& node, const K& key);

    /**
    * Private helper function for the public height function.
    * @param subRoot
    * @return The height of the subtree
    */
    int height(const Node* subRoot) const;

    /**
     * Swap the keys and values of two nodes.
     * @param first The first node to swap
     * @param second The node to swap with
     */
    void swap(Node*& first, Node*& second);

    /**
     * Helper function for #operator= and BST(const BST &).
     * @param subRoot The current node in the recursion
     */
    Node* copy(const Node* subRoot);

    /**
     * Private helper function for clear that clears beneath the parameter node.
     * @param subRoot The current node in the recursion
     */
    void clear(Node* subRoot);

    /**
     * Gets the in-order traversal of an BST tree's keys.
     * @param subRoot The current node in the recursion
     */
    void getInorderTraversal(const Node* subRoot, std::vector<K>& traversal) const;

    /**
     * Gets the pre-order traversal of an BST tree's keys.
     * @param subRoot The current node in the recursion
     */
    void getPreorderTraversal(const Node* subRoot, std::vector<K>& traversal) const;

    /** This variable is used for grading. */
    std::ostream* _out;

    /** This variable tests the order of function calls **/
    std::vector<std::string> functionCalls;
};


/**
 * Builds a BST by inserting all elements in the list
 * @param std::vector<std::pair<K, V>> The input list consisting of (string, int) pairs
 * @return The BST containing all unique inputs (ignoring duplicates once inserted once)
 */
template <class K, class V>
BST<K, V> listBuild(std::vector<std::pair<K, V>> inList);


/**
 * Builds all possible permutations of an input list (treating all items as unique)
 * @param std::vector<std::pair<K, V>> The input list consisting of (string, int) pairs
 * @return The histogram of tree heights for all possible permutations. 
 * HINT: For an input dataset of size n, there should be n! total height counts.
 */
template <class K, class V>
std::vector<int> allBuild(std::vector<std::pair<K, V>> inList);

#include "bst_given.hpp"
#include "bst.hpp"
